<?php
  $page_title = 'Admin Home Page';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(1);
?>
<?php
 $c_categorie     = count_by_id('categories');
 $c_product       = count_by_id('products');
 $c_sale          = count_by_id('sales');
 $c_user          = count_by_id('users');
 $products_sold   = find_higest_saleing_product('10');
 $recent_products = find_recent_product_added('5');
 $recent_sales    = find_recent_sale_added('5')
?>
<?php include_once('layouts/header.php'); ?>
<style>
.red-background-container {
    /* background: url('libs/images/banner.jpg') ; */
     background-color: #DAD3BE; 
    position: F1F1F1/0;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: -1;
    height: 100%;
    width: 100%;
}
</style>
<div class="row">
   <div class="col-md-6">
     <?php echo display_msg($msg); ?>
   </div>
</div>

<div class="single-container">
<div class="red-background-container"></div>   
<div>
<div class="row">
        <a href="users.php" style="color:black;">
            <div class="col-md-6" style="height:300px !important">
                <div class="panel panel-box clearfix" style="height: 250px !important;">
                    <div class="panel-icon pull-left bg-secondary1" >
                        <i class="glyphicon glyphicon-user"></i>
                    </div>
                    <div class="panel-value pull-right">
                        
                        <p class="text-muted" style="font-size: 20px; padding-top: 60px;">Users</p>
                    </div>
                </div>
            </div>
        </a>

        <a href="categorie.php" style="color:black;">
        <div class="col-md-6" style="height:300px !important">
                <div class="panel panel-box clearfix" style="height: 250px !important;">
                    <div class="panel-icon pull-left bg-red">
                        <i class="glyphicon glyphicon-th-large"></i>
                    </div>
                    <div class="panel-value pull-right">
                       
                        <p class="text-muted" style="font-size: 20px; padding-top: 60px;">Categories</p>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="row">
    <a href="product.php" style="color:black;">
    <div class="col-md-6" style="height:300px !important ;padding-top : 20px">
                <div class="panel panel-box clearfix" style="height: 250px !important;">
                    <div class="panel-icon pull-left bg-blue2">
                        <i class="glyphicon glyphicon-shopping-cart"></i>
                    </div>
                    <div class="panel-value pull-right">
                      
                        <p class="text-muted" style="font-size: 20px; padding-top: 60px;">Products</p>
                    </div>
                </div>
            </div>
        </a>

        <a href="sales.php" style="color:black; ">
        <div class="col-md-6" style="height:300px !important ;padding-top : 20px">
                <div class="panel panel-box clearfix" style="height: 250px !important;">
                    <div class="panel-icon pull-left bg-green">
                        <i class="glyphicon">₨</i>
                    </div>
                    <div class="panel-value pull-right">
                        
                        <p class="text-muted" style="font-size: 20px; padding-top: 60px;">Sales</p>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>


      
    </div>
</div>

  
  
    </div>
  </div>
 </div>
</div>
 </div>
  <div class="row">

  </div>



<?php include_once('layouts/footer.php'); ?>
