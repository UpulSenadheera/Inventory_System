<?php
  ob_start();
  require_once('includes/load.php');
  if($session->isUserLoggedIn(true)) { redirect('home.php', false);}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Inventory Management System</title>

    <!-- Stylesheet link -->
    <link rel="stylesheet" type="text/css" href="css/login.css">
    
    <script src="https://kit.fontawesome.com/323c9d2792.js" crossorigin="anonymous"></script>


</head>
<body>
    <div class="header">
        <div clsss ="homepageContainer">
        <a href="index.php">Login</a>
        <!-- Content inside the header -->
        </div>
    
    </div>
        <div class="banner">
                <div class="homepageContainer">
                    <div class="bannerHeader">
                        <h1>SACHITHRA STUDIO</h1>
                        <p>Inventory Management System</p>
                    </div>
                    <p class="bannerTagline">
                        Track yourservice and your entire supplychain
                        purchase to product end sim_card_alert
                        wwell come back 

                    </p>
                   
                    <div class="bannerIcons">
                        <a href=""><i class="fab fa-apple"></i></a>
                        <a href=""><i class="fab fa-android"></i></a>
                        <a href=""><i class="fab fa-windows"></i></a>

                    </div>
                </div>

        </div>

        <div>
        <div class="homepageContainer">
            <div class="homepageFeatures">
                    <div class="homepageFeature">
                        <span class="featureIcon"><i class="fas fa-gear"></i></span>
                        <h3 class="featureTitle">Editable theme</h3>
                        <p class="featureDescription">Studio Sachithran sit amet,consecteture
                            display
                            suspendisse frinilla.

                        </p>
                    </div>
                    
                    <div class="homepageFeature">
                        <span class="featureIcon"><i class="fas fa-star"></i></span>
                        <h3 class="featureTitle">Flag Design</h3>
                        <p class="featureDescription">Studio Sachithran sit amet,consecteture
                            display
                            suspendisse .

                        </p>
                    </div>
                    <div class="homepageFeature">
                        <span class="featureIcon"><i class="fas fa-globe"></i></span>
                        <h3 class="featureTitle">Reach Your Customers</h3>
                        <p class="featureDescription">Studio Sachithran sit amet,consecteture
                            display
                             frinilla.
    
                        </p>
                    </div>
                </div>
        </div>
    </div>
    
    <div class="homepagecontainer">
        <div class="homepageNotified">
          <div class="homepageNotifiedContainer">
            <h3>Get Notified Of Any Updates!</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse fringilla fringilla nisl congue congue. Maecenas nec condimentum libero, at elementum mauris. Phasellus eget nisi dapibus, ultricies nisl at, hendrerit risus eu ornare luctus id sollicitudin ante lobortis at.</p>
            <form action="">
              <div class="formContainer">
                <input type="text" placeholder="Email Address" />
                <button>Notify</button>
              </div>
            </form>
          </div>
          <div class="video">
            <iframe src="https://www.youtube.com/embed/48VkVOHYGWw" width="500px" height="300px" frameborder="0"></iframe>
          </div>
        </div>
      </div>
      <div class="socials">
        <div class="homepageContainer">
            <h3 class="socialHeader">Say Hi & Get in Touch</h3>
            <p class="socialText">Lorem ipsum dolor sit amet, consectetur adipiscing elit suspendisse.</p>
            <div class="socialIconsContainer">
                <a href=""><i class="fa fa-twitter"></i></a>
                <a href=""><i class="fa fa-facebook"></i></a>
                <a href=""><i class="fa fa-pinterest"></i></a>
                <a href=""><i class="fa fa-google-plus"></i></a>
                <a href=""><i class="fa fa-linkedin"></i></a>
                <a href=""><i class="fa fa-youtube"></i></a>
            </div>
            
        </div>
    </div>
    
    <div class="footer">
        <div class="homepagecontainer">
          <a href="">Contact</a>
          <a href="">Download</a>
          <a href="">Press</a>
          <a href="">Email</a>
          <a href="">Support</a>
          <a href="">Privacy Policy</a>
        </div>                
      </div>
    

            
</body>
</html>

