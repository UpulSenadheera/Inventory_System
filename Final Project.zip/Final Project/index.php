<?php
  ob_start();
  require_once('includes/load.php');
  if($session->isUserLoggedIn(true)) { redirect('home.php', false);}
?>
<?php include_once('layouts/header.php'); ?>
<style>
  body {
    background: url('libs/images/banner.jpg') no-repeat center center fixed;
    background-size: cover;
  }
  .login-page {
    background: rgba(255, 255, 255, 0.8);
    padding: 20px;
    border-radius: 10px;
    max-width: 400px;
    margin: 100px auto;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
  }
  .btn-green {
    background-color: green;
    border-color: green;
    color: white; /* Ensures text color is readable */
  }
</style>

<div class="login-page">
    <div class="text-center">
       <h1>Welcome</h1>
       <h4>You Can Log In to the System</h4>
    </div>
    <?php echo display_msg($msg); ?>
    <form method="post" action="auth.php" class="clearfix">
        <div class="form-group">
            <label for="username" class="control-label">Enter Your Username</label>
            <input type="text" class="form-control" name="username" placeholder="Username">
        </div>
        <div class="form-group">
            <label for="Password" class="control-label">Enter Your Password</label>
            <input type="password" name="password" class="form-control" placeholder="Password">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-green" style="border-radius:0%">Login</button>
        </div>
    </form>
</div>
</body>
<?php include_once('layouts/footer.php'); ?>
